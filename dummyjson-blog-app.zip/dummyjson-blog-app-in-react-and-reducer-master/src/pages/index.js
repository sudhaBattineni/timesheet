import Login from "../pages/LoginPage/LoginPage";
import Home from "../pages/HomePage/HomePage";
import SingleBlog from "../pages/SingleBlogPage/SingleBlogPage";

export {Login , Home, SingleBlog};