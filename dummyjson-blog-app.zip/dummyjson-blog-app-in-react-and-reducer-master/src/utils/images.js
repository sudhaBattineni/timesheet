import banner_image from "../assets/images/banner_image.png";
import search_icon from "../assets/images/search_icon.png";
import loader from "../assets/images/loader.svg";

export {banner_image, search_icon, loader};